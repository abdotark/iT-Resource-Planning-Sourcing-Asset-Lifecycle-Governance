# Acquisition Process

## Proposed process
1. Identify business need.
2. Confirm requirements and ownership.
3. Compare procurement / licensing / cloud options.
4. Perform security, privacy, legal, and supplier due diligence.
5. Approve budget and business case.
6. Purchase or provision the resource.
7. Record the asset/service and owner.
8. Review performance and renew, change, or retire.

Adapt this as a proposed process; do not describe it as Jumia's actual process without evidence.
