# Week 2 — Capacity Planning & Acquisition

## Required outputs
- Capacity plan
- Demand forecast
- Acquisition process
- Procurement governance checklist
- Budget alignment matrix

Create estimates only when assumptions and calculation methods are documented. Do not imply internal Jumia budgets or demand figures are known unless published.
