# Procurement Governance Checklist

- [ ] Business need and requirements documented
- [ ] Alternatives evaluated
- [ ] Total cost of ownership considered
- [ ] Security and privacy review completed
- [ ] Legal / compliance requirements checked
- [ ] Supplier due diligence completed
- [ ] Budget approval recorded
- [ ] Contract, SLA, and renewal terms reviewed
- [ ] Owner and custodian assigned
- [ ] Asset/service register updated
