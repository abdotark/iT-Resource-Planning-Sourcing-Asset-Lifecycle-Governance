# Capacity Plan — Jumia

## Scope and planning horizon
_To be defined._

## Current-state evidence
_Record public evidence and limitations._

## Capacity assumptions and scenarios
_Document assumptions, drivers, and calculation method._

## Capacity risks and recommendations
_To be completed._
