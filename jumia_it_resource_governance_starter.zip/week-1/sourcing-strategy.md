# Sourcing Strategy Paper — Jumia

## 1. Executive summary
_To be completed after evidence gathering._

## 2. Scope and methodology
State the business/technology scope, research date, sources used, and limitations.

## 3. Company and operating context
Summarize only what reliable public sources support.

## 4. IT resource and capability overview
Link to the [IT Asset Inventory](it-asset-inventory.csv). Distinguish documented resources from inferred capabilities.

## 5. Sourcing options
Evaluate:
- In-house / insourcing
- Outsourcing
- Cloud or managed services
- Hybrid sourcing
- Strategic partnerships

## 6. Analysis and recommendations
For each recommendation, include evidence, rationale, expected benefits, trade-offs, risks, and assumptions.

## 7. Limitations and information gaps
Identify internal information that is not publicly available.

## 8. References
Use source IDs from `../references/sources.md`.
