# Sourcing Risk Assessment — Jumia

## Method
Define likelihood and impact scales before scoring. Explain the basis for each rating. Separate confirmed risks disclosed by the company from general risks relevant to the sourcing option being assessed.

| Risk ID | Sourcing option / area | Risk description | Evidence or rationale | Likelihood | Impact | Existing controls (if publicly documented) | Proposed mitigation | Owner |
|---|---|---|---|---|---|---|---|---|
| R-01 | To be researched | | | | | | | |

## Review notes
- Avoid claiming a control exists unless a source confirms it.
- Mark recommendations as proposed controls, not current company practice.
