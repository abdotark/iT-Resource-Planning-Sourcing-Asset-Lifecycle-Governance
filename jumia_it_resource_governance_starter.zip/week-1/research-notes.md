# Week 1 Research Notes

Use one entry per useful source or finding.

## Finding template
- **Finding ID:**
- **Claim / observation:**
- **Fact, analysis, recommendation, or unknown:**
- **Source ID:**
- **Why it matters to Week 1:**
- **Confidence / limitations:**
- **Follow-up needed:**
