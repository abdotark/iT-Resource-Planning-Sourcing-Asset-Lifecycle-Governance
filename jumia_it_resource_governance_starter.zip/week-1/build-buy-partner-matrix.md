# Build / Buy / Partner Decision Matrix — Jumia

## Purpose
Compare sourcing options for selected IT capabilities. Do not assume Jumia's actual internal decisions unless a source confirms them.

## Scoring method
Agree on a consistent scale (for example, 1 = weak, 5 = strong) and define what each criterion means before scoring. Record evidence and assumptions for each score.

| Capability / Need | Build (in-house) | Buy (commercial solution) | Partner (external provider) | Criteria and rationale | Evidence / assumptions |
|---|---:|---:|---:|---|---|
| To be researched | | | | | |

## Suggested criteria
- Total cost of ownership
- Time to implement
- Security and privacy
- Scalability
- Integration complexity
- Internal skills required
- Vendor dependency / lock-in
- Compliance and resilience

## Recommendation
_To be completed after evidence gathering and scoring._
