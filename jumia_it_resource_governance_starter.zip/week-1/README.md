# Week 1 — IT Resource Planning & Sourcing Strategy

## Required deliverables
1. IT Asset Inventory
2. Sourcing Strategy Paper
3. Build/Buy/Partner Decision Matrix
4. Sourcing Risk Assessment

## Work order
1. Collect and cite public evidence about Jumia.
2. Create the asset inventory with an evidence/status field.
3. Analyze sourcing options.
4. Compare build, buy, and partner options using consistent criteria.
5. Assess sourcing risks and proposed mitigations.
