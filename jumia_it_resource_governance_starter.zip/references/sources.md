# Research Sources

Use one source ID for each source and cite it in the relevant documents.

| Source ID | Title | Publisher | URL | Publication date | Access date | Relevant finding / page | Used in |
|---|---|---|---|---|---|---|---|
| S-001 | To be added | | | | | | |

## Source quality rules
- Prefer official company reports, regulatory filings, and official company pages.
- Use credible third-party reporting for context where needed.
- Record the date accessed.
- Never cite a source for a claim it does not support.
