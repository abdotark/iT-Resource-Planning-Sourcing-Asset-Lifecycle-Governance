# Vendor Exit Strategy

Cover:
- Exit triggers and approval authority
- Data export and secure deletion
- Transition and continuity arrangements
- Knowledge and documentation handover
- Replacement provider or internal transition
- Contractual notice, fees, and obligations
- Access revocation and credential rotation
- Exit testing and sign-off

Company-specific contract terms must not be invented.
