# IT Resource Dashboard — Specification

## Proposed dashboard sections
- Asset inventory by category and evidence status
- Sourcing option distribution
- Risk summary by likelihood and impact
- Capacity and demand indicators
- Vendor SLA / KPI performance (where data is available)
- Budget versus forecast (where data is available)
- Open actions and owners

## Data limitations
Clearly label sample, estimated, and publicly sourced data. Do not display invented values as actual Jumia metrics.
