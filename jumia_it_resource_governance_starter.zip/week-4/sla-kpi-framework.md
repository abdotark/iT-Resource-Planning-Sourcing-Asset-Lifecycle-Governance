# SLA / KPI Framework

| KPI / SLA | Definition | Calculation | Target | Data source | Review frequency | Owner |
|---|---|---|---|---|---|---|
| Service availability | To be defined | Uptime / agreed service time | Set after research | To be identified | Monthly | To be assigned |

Targets must be justified and labelled as proposed if not publicly documented.
