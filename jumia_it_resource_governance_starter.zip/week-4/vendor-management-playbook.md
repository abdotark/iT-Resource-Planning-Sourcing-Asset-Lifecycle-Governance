# Vendor Management Playbook

## Vendor lifecycle
1. Identify need and sourcing route
2. Assess vendor capability and risk
3. Perform due diligence
4. Negotiate contract and SLA
5. Onboard and assign service owner
6. Monitor service, risk, cost, and compliance
7. Review and remediate performance
8. Renew, transition, or exit

This is a proposed playbook unless evidence confirms Jumia uses the same process.
