# Week 4 — Vendor / Contract Governance & Metrics

## Required outputs
- Vendor management playbook
- SLA / KPI framework
- Vendor risk register
- Exit strategy
- IT resource dashboard
- Final IT resource governance report
